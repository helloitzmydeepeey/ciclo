<?php
/**
 * Copyright ©2021 s All rights reserved.
 * See COPYING.txt for license details.
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'HTML_Additional', __DIR__);
